

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end
