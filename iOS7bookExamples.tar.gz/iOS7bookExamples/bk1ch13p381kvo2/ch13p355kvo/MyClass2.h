

#import <Foundation/Foundation.h>


@interface MyClass2 : NSObject
@end
