

@import MediaPlayer;

@interface MyVolumeView : MPVolumeView



@end
