
#import <UIKit/UIKit.h>


@interface MyCell : UITableViewCell

@property (nonatomic, weak) IBOutlet UITextField* textField;

@end
