

#import <UIKit/UIKit.h>

@interface MyLayoutManager : NSLayoutManager

@property NSRange wordRange;

@end
