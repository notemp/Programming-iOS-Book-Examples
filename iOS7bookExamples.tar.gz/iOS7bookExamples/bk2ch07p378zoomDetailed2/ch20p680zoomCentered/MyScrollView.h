

#import <Foundation/Foundation.h>


@interface MyScrollView : UIScrollView

@end
