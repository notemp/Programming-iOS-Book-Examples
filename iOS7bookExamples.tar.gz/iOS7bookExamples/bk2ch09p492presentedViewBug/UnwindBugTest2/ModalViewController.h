
#import <UIKit/UIKit.h>

@interface ModalViewController : UIViewController

@end
