

#import <Foundation/Foundation.h>

@interface MyView2 : UIView

@end
