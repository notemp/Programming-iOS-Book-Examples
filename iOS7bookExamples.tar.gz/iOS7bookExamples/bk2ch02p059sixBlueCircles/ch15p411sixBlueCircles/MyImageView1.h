

#import <UIKit/UIKit.h>

@interface MyImageView1 : UIImageView

@end
