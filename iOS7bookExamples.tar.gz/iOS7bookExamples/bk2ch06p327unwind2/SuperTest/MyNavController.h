

#import <UIKit/UIKit.h>

@interface MyNavController : UINavigationController

@end
