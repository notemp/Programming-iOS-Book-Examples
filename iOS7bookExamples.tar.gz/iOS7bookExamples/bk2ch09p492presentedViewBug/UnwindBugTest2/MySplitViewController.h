
#import <UIKit/UIKit.h>

@interface MySplitViewController : UISplitViewController

@end
