

#import <UIKit/UIKit.h>


@interface MyView : UIView 


@end
