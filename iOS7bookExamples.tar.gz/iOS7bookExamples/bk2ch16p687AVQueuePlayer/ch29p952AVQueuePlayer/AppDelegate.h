//
//  AppDelegate.h
//  ch29p952AVQueuePlayer
//
//  Created by Matt Neuburg on 11/3/13.
//  Copyright (c) 2013 Matt Neuburg. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
