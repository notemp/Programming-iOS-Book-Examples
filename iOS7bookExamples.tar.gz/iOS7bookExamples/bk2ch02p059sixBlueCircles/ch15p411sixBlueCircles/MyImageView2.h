
#import <UIKit/UIKit.h>

@interface MyImageView2 : UIImageView

@end
