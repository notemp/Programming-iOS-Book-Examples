

#import <CoreImage/CoreImage.h>

@interface MyVignetteFilter : CIFilter
@end
