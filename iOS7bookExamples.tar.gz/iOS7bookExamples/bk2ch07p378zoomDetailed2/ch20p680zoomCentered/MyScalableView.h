

#import <UIKit/UIKit.h>

@interface MyScalableView : UIView


@end
