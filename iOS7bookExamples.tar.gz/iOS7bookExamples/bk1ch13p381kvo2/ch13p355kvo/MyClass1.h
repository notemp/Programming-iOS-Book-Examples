

#import <Foundation/Foundation.h>


@interface MyClass1 : NSObject 
@property (nonatomic, copy) NSString* value;
@end

