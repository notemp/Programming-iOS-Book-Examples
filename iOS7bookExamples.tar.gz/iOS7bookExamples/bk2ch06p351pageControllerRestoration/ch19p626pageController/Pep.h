
#import <UIKit/UIKit.h>

@interface Pep : UIViewController

- (id) initWithPepBoy: (NSString*) boy nib: (NSString*) nib bundle: (NSBundle*) bundle;

@property (nonatomic, copy) NSString* boy;

@end
