

#import <UIKit/UIKit.h>

@interface MyNavigationController : UINavigationController

@end
