

#import <UIKit/UIKit.h>

@interface MyMandelbrotView : UIView

- (void) drawThatPuppy;

@end
