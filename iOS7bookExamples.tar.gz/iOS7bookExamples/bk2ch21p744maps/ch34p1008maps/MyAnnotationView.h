
#import <Foundation/Foundation.h>
@import MapKit;


@interface MyAnnotationView : MKAnnotationView 

@end
