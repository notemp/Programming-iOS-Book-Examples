

#import <UIKit/UIKit.h>

@interface MyTextField : UITextField

@end
