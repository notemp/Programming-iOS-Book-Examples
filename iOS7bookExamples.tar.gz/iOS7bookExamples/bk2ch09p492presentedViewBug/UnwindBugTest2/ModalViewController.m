
#import "ModalViewController.h"

@interface ModalViewController ()

@end

@implementation ModalViewController

@end
